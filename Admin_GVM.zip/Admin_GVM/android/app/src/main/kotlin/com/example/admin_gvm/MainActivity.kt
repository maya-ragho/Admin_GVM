package com.example.admin_gvm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
